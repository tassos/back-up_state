Back-up State
=============

A cinnamon applet for checking the state of the date of the last succefull back-up.

User Input
==========

The user needs to select a rsync log file to be checked, and a string to be used for identifying a succesfull back-up. She also needs to define the limits for the warning and error message. If a back-up hasn't run sucessfully whithin a selected amount of days, a warning/error icon appears on the applet bar warning the user to check her back-ups.
